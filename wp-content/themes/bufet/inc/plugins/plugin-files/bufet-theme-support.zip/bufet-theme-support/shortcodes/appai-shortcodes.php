<?php 

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { 
	exit; 
}




/**
 * =======================================================
 *    Registerd Shortcode
 * =======================================================
 */


